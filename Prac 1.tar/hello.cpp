#include <iostream>

int main() {
	std::cout<<"Hello, world! I am u21707198"<<std::endl;
	return 0;
}
